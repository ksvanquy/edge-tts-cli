import json
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from tts_cli.core.models import SubtitleCue
from tts_cli.subtitle.srt import cues_to_srt, format_srt_time


@dataclass(frozen=True)
class OutputContext:
    folder: Path
    word_cues: list[SubtitleCue]
    subtitle_cues: list[SubtitleCue]
    audio_path: Path


class OutputFormatHandler(Protocol):
    extension: str

    def write(self, context: OutputContext) -> Path:
        ...


class Mp3OutputHandler:
    extension = "mp3"

    def write(self, context: OutputContext) -> Path:
        return context.audio_path


class SrtOutputHandler:
    extension = "srt"

    def write(self, context: OutputContext) -> Path:
        path = context.folder / "subtitle.srt"
        path.write_text(cues_to_srt(context.subtitle_cues), encoding="utf-8", newline="\n")
        return path


class VttOutputHandler:
    extension = "vtt"

    def write(self, context: OutputContext) -> Path:
        path = context.folder / "subtitle.vtt"
        cues = []
        for cue in context.subtitle_cues:
            start = format_srt_time(cue.start).replace(",", ".")
            end = format_srt_time(cue.end).replace(",", ".")
            cues.append(f"{start} --> {end}\n{cue.text.strip()}")
        content = "WEBVTT\n\n" + "\n\n".join(cues) + ("\n" if cues else "")
        path.write_text(content, encoding="utf-8", newline="\n")
        return path


class JsonOutputHandler:
    extension = "json"

    def write(self, context: OutputContext) -> Path:
        path = context.folder / "subtitle.json"
        payload = [
            {
                "index": index,
                "start": cue.start,
                "end": cue.end,
                "text": cue.text.strip(),
            }
            for index, cue in enumerate(context.subtitle_cues, start=1)
        ]
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return path