from pathlib import Path

from tts_cli.output.formats import (
    JsonOutputHandler,
    Mp3OutputHandler,
    OutputContext,
    OutputFormatHandler,
    SrtOutputHandler,
    VttOutputHandler,
)


class OutputResolver:
    def __init__(self, handlers: dict[str, OutputFormatHandler] | None = None):
        self.handlers = handlers or {
            "mp3": Mp3OutputHandler(),
            "srt": SrtOutputHandler(),
            "vtt": VttOutputHandler(),
            "json": JsonOutputHandler(),
        }

    def resolve(self, formats: str | list[str] | None) -> list[OutputFormatHandler]:
        values = formats if isinstance(formats, list) else (formats or "mp3,srt").split(",")
        names = [value.strip().lower().lstrip(".") for value in values if value.strip()]
        if not names:
            raise ValueError("--formats không được rỗng.")
        unknown = sorted(set(names) - self.handlers.keys())
        if unknown:
            supported = ", ".join(sorted(self.handlers))
            raise ValueError(f"Format không được hỗ trợ: {', '.join(unknown)}. Chỉ nhận: {supported}")
        return [self.handlers[name] for name in dict.fromkeys(names)]

    def required_files(self, formats: str | list[str] | None) -> set[str]:
        return {self.filename(handler) for handler in self.resolve(formats)}

    def artifact_paths(self, folder: Path, formats: str | list[str] | None) -> list[Path]:
        return [folder / self.filename(handler) for handler in self.resolve(formats)]

    @staticmethod
    def filename(handler: OutputFormatHandler) -> str:
        return "audio.mp3" if handler.extension == "mp3" else f"subtitle.{handler.extension}"

    def write(self, context: OutputContext, formats: str | list[str] | None) -> list[Path]:
        handlers = self.resolve(formats)
        paths = []
        try:
            paths = [handler.write(context) for handler in handlers]
            if not any(handler.extension == "mp3" for handler in handlers) and context.audio_path.exists():
                context.audio_path.unlink()
            return paths
        except Exception:
            self.cleanup(context.folder, formats)
            raise

    def cleanup(
        self,
        folder: Path,
        formats: str | list[str] | None,
        remove_folder: bool = False,
    ) -> None:
        paths = set(self.artifact_paths(folder, formats))
        paths.add(folder / "audio.mp3")
        for path in paths:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
        if remove_folder:
            try:
                folder.rmdir()
            except OSError:
                pass