import re
from pathlib import Path


def get_next_number(output_root: Path, start: int = 1) -> int:
    if not output_root.exists():
        return start
    numbers = [
        int(match.group(1))
        for item in output_root.iterdir()
        if item.is_dir()
        if (match := re.fullmatch(r"(\d+)", item.name))
    ]
    return max(numbers, default=start - 1) + 1


def create_output_folder(output_root: Path, number: int) -> Path:
    output_root.mkdir(parents=True, exist_ok=True)
    folder = output_root / f"{number:03d}"
    folder.mkdir(parents=True, exist_ok=False)
    return folder
