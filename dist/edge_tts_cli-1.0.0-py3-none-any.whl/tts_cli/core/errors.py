"""Public error names for application and provider boundaries."""


class TTSCLIError(Exception):
	"""Base exception for expected CLI failures."""

__all__ = ["TTSCLIError"]