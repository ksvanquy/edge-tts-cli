"""Text input processing."""
