"""External I/O adapters."""
