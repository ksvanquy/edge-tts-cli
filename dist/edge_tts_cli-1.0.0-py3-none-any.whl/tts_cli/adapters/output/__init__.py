"""Output file adapters."""

from tts_cli.core.models import OutputContext
from tts_cli.adapters.output.resolver import OutputResolver

__all__ = ["OutputContext", "OutputResolver"]
