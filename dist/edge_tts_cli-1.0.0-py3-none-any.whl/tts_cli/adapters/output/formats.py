import json
from pathlib import Path
from typing import Protocol

from tts_cli.adapters.subtitle.srt import cues_to_srt, format_srt_time
from tts_cli.core.models import OutputContext


class OutputFormatHandler(Protocol):
    extension: str

    def write(self, context: OutputContext) -> Path:
        ...


class Mp3OutputHandler:
    extension = "mp3"

    def write(self, context: OutputContext) -> Path:
        return context.audio_path


class SrtOutputHandler:
    extension = "srt"

    def write(self, context: OutputContext) -> Path:
        path = context.folder / "subtitle.srt"
        path.write_text(cues_to_srt(context.subtitle_cues), encoding="utf-8", newline="\n")
        return path


class VttOutputHandler:
    extension = "vtt"

    def write(self, context: OutputContext) -> Path:
        cues = []
        for cue in context.subtitle_cues:
            start = format_srt_time(cue.start).replace(",", ".")
            end = format_srt_time(cue.end).replace(",", ".")
            cues.append(f"{start} --> {end}\n{cue.text.strip()}")
        content = "WEBVTT\n\n" + "\n\n".join(cues) + ("\n" if cues else "")
        path = context.folder / "subtitle.vtt"
        path.write_text(content, encoding="utf-8", newline="\n")
        return path


class JsonOutputHandler:
    extension = "json"

    def write(self, context: OutputContext) -> Path:
        payload = [
            {"index": index, "start": cue.start, "end": cue.end, "text": cue.text.strip()}
            for index, cue in enumerate(context.subtitle_cues, start=1)
        ]
        path = context.folder / "subtitle.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return path
